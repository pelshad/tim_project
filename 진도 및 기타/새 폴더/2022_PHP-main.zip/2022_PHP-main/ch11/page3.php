<?php
    session_start();
    $_SESSION['g'] = "This is a Global variable";
?>
<a href="page4.php">Next Page</a>