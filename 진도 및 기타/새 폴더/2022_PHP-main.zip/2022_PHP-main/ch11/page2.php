<?php
    print $g;