<?php
    $n1 = 30;
    $n2 = 80;
    $sum = $n1 + $n2;

    print $sum;

    print "<br>";
    
    $sub = 12.3 - 42.72;
    print $sub;
?>