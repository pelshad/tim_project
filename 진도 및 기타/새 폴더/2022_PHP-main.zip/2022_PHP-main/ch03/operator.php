<?php
    $num = 10;
    // 10는(은) 짝수입니다.
    
    if($num % 2 === 0) 
    {
        print "${num}는(은) 짝수입니다.";
    } 
    else 
    {
        print "${num}는(은) 홀수입니다.";
    }
?>