<?php
    $num = 11;
    $odd_even = "홀";
    
    if($num % 2 === 0) 
    {
       $odd_even = "짝";
    }     

    print "${num}는(은) ${odd_even}수입니다.";
?>