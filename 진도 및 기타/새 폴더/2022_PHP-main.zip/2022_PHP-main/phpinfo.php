<?php
    echo phpinfo();