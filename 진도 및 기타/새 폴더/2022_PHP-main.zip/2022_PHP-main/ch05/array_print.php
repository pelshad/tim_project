<?php
    $numbers = array(10, 20, 30, 40, 50);

    print $numbers . "<br>";
    print_r($numbers);
    print "<br>";

    array_push($numbers, 60, 100, 200);
    print_r($numbers);
    print "<br>";
?>