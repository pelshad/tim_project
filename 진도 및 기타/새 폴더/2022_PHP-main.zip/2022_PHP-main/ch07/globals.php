<?php
    $x = 10;

    foreach($GLOBALS as $key => $var)
    {
        print $key . " : ";
        print $var;
        print "<br>";
    }

?>