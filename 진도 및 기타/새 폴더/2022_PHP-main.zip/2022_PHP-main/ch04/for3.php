<?php
    for($i=1; $i<10; $i++)
    {
        for($z=1; $z<10; $z++)
        {
            print "i: ${i} - z: ${z} <br>";
        }
        print "---------------<br>";
    }
?>