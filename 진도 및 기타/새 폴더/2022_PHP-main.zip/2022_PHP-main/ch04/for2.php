<?php
    for($i=0; $i<1000; $i++) 
    {
        echo "안녕하세요 <br>";
        echo "반갑습니다. <br>";
    }    
?>