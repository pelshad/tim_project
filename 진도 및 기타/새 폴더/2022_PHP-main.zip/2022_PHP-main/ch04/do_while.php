<?php
     print "-- 시작 -- <br>";
     do {
        $r_val = rand(1, 10);        
        print "r_val : $r_val <br>";
     } while($r_val != 10);
     print "-- 끝 -- <br>";
?>